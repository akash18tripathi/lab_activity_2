# SSD_LAB_ACTIVITY_2

## q1.sh

1) Give executing permissions for file q1.sh by executing the below command
    
                      chmod u+x q1.sh

2)Run the script by executing following command

                        bash q1.sh <file_name>

## q2.sh

1) Give executing permissions for file q2.sh by executing the below command
    
                      chmod u+x q2.sh

2)Run the script by executing following command

                        bash q2.sh


